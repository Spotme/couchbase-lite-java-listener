TJWS 1.105

Read release notes inside zip.

After unzipping :
Change to ./bin directory and start tjws.bat, tjws.sh, 
or tjws.lnk in dependency on your OS.
Access server at http://localhost, or http://localhost:8080 (on Unix/Linux/Mac)

Android and Blackberry versions are not bundled with this version. Download them
separately and then you can copy them to android directory of webroot to install
on a mobile device follow below instructions.
Download Atjeews.apk to run the server on Android platform and Atjeews.bar for Blackberry.
The mobile versions are available in android web path, like http://localhost/android
Atjeews can be also downloaded from Google Play.

Check TJWS home at http://tjws.sf.net